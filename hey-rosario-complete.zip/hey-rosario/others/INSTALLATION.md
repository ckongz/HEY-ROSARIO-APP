# Installation Guide - Hey Rosario!

## Prerequisites
- PHP 8.0 or higher
- MySQL 8.0 or higher
- Apache or Nginx web server
- Composer (optional, for dependencies)

## Step-by-Step Installation

### 1. Download and Extract
```bash
git clone https://github.com/yourusername/hey-rosario.git
cd hey-rosario
```

### 2. Set Up Database
```bash
# Create database
mysql -u root -p

# Import schema
mysql -u root -p < database/database-schema.sql
```

### 3. Configure Database Connection
Edit `php/db-connection.php`:
```php
$host = 'localhost';
$dbname = 'hey_rosario';
$username = 'your_username';  // Change this
$password = 'your_password';   // Change this
```

### 4. Set File Permissions
```bash
chmod 755 -R hey-rosario/
chmod 777 uploads/
chmod 777 uploads/ids/
chmod 777 uploads/reports/
chmod 777 uploads/documents/
```

### 5. Configure Web Server

#### Apache
Edit your virtual host configuration:
```apache
<VirtualHost *:80>
    ServerName heyrosario.local
    DocumentRoot /path/to/hey-rosario
    
    <Directory /path/to/hey-rosario>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/heyrosario-error.log
    CustomLog ${APACHE_LOG_DIR}/heyrosario-access.log combined
</VirtualHost>
```

#### Nginx
```nginx
server {
    listen 80;
    server_name heyrosario.local;
    root /path/to/hey-rosario;
    index index.html index.php;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
}
```

### 6. Update hosts file (optional, for local development)
```
127.0.0.1 heyrosario.local
```

### 7. Initialize Admin Account
The default admin credentials are:
- Username: `admin`
- Password: `admin123`

**IMPORTANT:** Change this immediately after first login!

### 8. Test Installation
1. Open browser: `http://localhost/hey-rosario/` or `http://heyrosario.local/`
2. Register a test account
3. Submit a test report
4. Login to admin dashboard

## Post-Installation

### Security Checklist
- [ ] Change default admin password
- [ ] Update database credentials
- [ ] Set up SSL certificate (HTTPS)
- [ ] Configure email settings in config.php
- [ ] Enable error logging
- [ ] Set up regular database backups
- [ ] Configure firewall rules
- [ ] Review file upload restrictions

### Add Images
1. Upload logo files to `images/`
2. Add hero images to `images/`
3. Upload tourism photos to `images/`
4. Add icons to `images/`

### Google Maps Integration
1. Get API key from Google Cloud Console
2. Update config.php with your API key
3. Enable Maps JavaScript API

### Email Configuration
1. Set up SMTP settings in config.php
2. Test email functionality
3. Configure notification templates

## Troubleshooting

### Database Connection Error
- Check credentials in php/db-connection.php
- Verify MySQL service is running
- Check database exists

### File Upload Not Working
- Verify upload directories exist
- Check directory permissions (777)
- Review php.ini upload settings

### Page Not Found (404)
- Enable mod_rewrite in Apache
- Check .htaccess is present
- Verify DocumentRoot is correct

### Session Issues
- Check PHP session configuration
- Verify session directory permissions
- Check session.save_path in php.ini

## Support
For technical support, contact:
- Email: support@heyrosario.gov.ph
- Phone: (045) 888-8889

## License
Proprietary software for Barangay Sto. Rosario, Angeles City
