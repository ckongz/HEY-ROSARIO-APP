<?php
/**
 * Hey Rosario! Configuration File
 */

// Site Configuration
define('SITE_NAME', 'Hey Rosario!');
define('SITE_URL', 'http://localhost/hey-rosario');
define('SITE_EMAIL', 'info@heyrosario.gov.ph');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'hey_rosario');
define('DB_USER', 'root');
define('DB_PASS', '');

// File Upload Configuration
define('MAX_FILE_SIZE', 10485760); // 10MB in bytes
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('ALLOWED_DOCUMENT_TYPES', ['application/pdf', 'application/msword']);

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour

// Pagination
define('ITEMS_PER_PAGE', 10);

// Google Maps API
define('GOOGLE_MAPS_API_KEY', 'YOUR_API_KEY_HERE');

// Email Configuration (SMTP)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-password');

// Development Mode
define('DEV_MODE', true); // Set to false in production
?>
