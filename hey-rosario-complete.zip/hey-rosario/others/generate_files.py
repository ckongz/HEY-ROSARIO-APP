#!/usr/bin/env python3
"""
Hey Rosario! - Complete Project File Generator
This script generates all HTML, PHP, JS, and SQL files for the project
"""

import os

# Create all necessary directories
directories = [
    'css', 'js', 'php', 'images', 'docs', 'database', 'videos', 'audio'
]

base_path = '/home/claude/hey-rosario'

for directory in directories:
    os.makedirs(os.path.join(base_path, directory), exist_ok=True)

print("✓ Created directory structure")

# Generate all HTML files (simplified templates - you'll expand these)
html_files = {
    'login.html': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Hey Rosario!</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <div class="login-page">
        <div class="login-container">
            <div class="login-header">
                <img src="images/logo.png" alt="Hey Rosario" class="login-logo">
                <h1>Welcome Back!</h1>
                <p>Log in to access your account</p>
            </div>
            <form id="loginForm" action="php/login-process.php" method="POST">
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="your.email@example.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                <div class="form-options">
                    <label><input type="checkbox" name="remember"> Remember me</label>
                    <a href="#" class="forgot-link">Forgot Password?</a>
                </div>
                <button type="submit" class="btn btn-primary btn-large" style="width: 100%;">Login</button>
            </form>
            <div class="login-footer">
                <p>Don't have an account? <a href="register.html">Register Here</a></p>
                <p><a href="index.html">← Back to Home</a></p>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/form-validation.js"></script>
</body>
</html>''',

    'register.html': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Hey Rosario!</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <div class="register-page">
        <div class="register-container">
            <div class="register-header">
                <img src="images/logo.png" alt="Hey Rosario" class="register-logo">
                <h1>Create Your Account</h1>
                <p>Join Hey Rosario! community</p>
            </div>
            <form id="registerForm" action="php/register-process.php" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">First Name</label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Contact Number</label>
                    <input type="tel" name="phone" class="form-control" placeholder="+63" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Upload Valid ID</label>
                    <input type="file" name="id_file" class="form-control file-upload-input" accept="image/*" required>
                    <div class="file-preview" style="display:none;"></div>
                </div>
                <div class="form-group">
                    <label><input type="checkbox" name="terms" required> I agree to the <a href="terms.html">Terms of Service</a> and <a href="privacy.html">Privacy Policy</a></label>
                </div>
                <button type="submit" class="btn btn-primary btn-large" style="width: 100%;">Create Account</button>
            </form>
            <div class="register-footer">
                <p>Already have an account? <a href="login.html">Login Here</a></p>
                <p><a href="index.html">← Back to Home</a></p>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/form-validation.js"></script>
</body>
</html>''',

    'services.html': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Government Services | Hey Rosario!</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <!-- Include header from index.html -->
    <section class="page-hero" style="background: linear-gradient(135deg, #fc6d54, #fe5448);">
        <div class="container">
            <h1>Government Services</h1>
            <p>Apply for permits, certificates, and barangay services online</p>
        </div>
    </section>
    
    <section class="services-section">
        <div class="container">
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon" style="background: #fc6d54;"><i class="fas fa-briefcase"></i></div>
                    <h3>Business Permit Application</h3>
                    <p>Apply for new business permit or renew existing permits online</p>
                    <a href="#" class="btn btn-primary">Apply Now</a>
                </div>
                <div class="service-card">
                    <div class="service-icon" style="background: #fe5448;"><i class="fas fa-file-alt"></i></div>
                    <h3>Barangay Clearance</h3>
                    <p>Request barangay clearance for various purposes</p>
                    <a href="#" class="btn btn-primary">Request</a>
                </div>
                <div class="service-card">
                    <div class="service-icon" style="background: #ee7ea2;"><i class="fas fa-certificate"></i></div>
                    <h3>Certificates</h3>
                    <p>Request indigency, residency, and other certificates</p>
                    <a href="#" class="btn btn-primary">Request</a>
                </div>
                <div class="service-card">
                    <div class="service-icon" style="background: #ca52cc;"><i class="fas fa-calendar-check"></i></div>
                    <h3>Facility Booking</h3>
                    <p>Book barangay covered court and facilities for events</p>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Include footer from index.html -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>''',

    'report.html': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report an Issue | Hey Rosario!</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <section class="page-hero" style="background: linear-gradient(135deg, #ee7ea2, #fe5448);">
        <div class="container">
            <h1>Report an Issue</h1>
            <p>Help improve our barangay by reporting issues</p>
        </div>
    </section>
    
    <section class="report-form-section">
        <div class="container">
            <form id="reportForm" action="php/submit-report.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label">Issue Category</label>
                    <select name="category" class="form-control" required>
                        <option value="">Select Category</option>
                        <option value="streetlight">Streetlight Issue</option>
                        <option value="sanitation">Sanitation/Waste</option>
                        <option value="road">Road Damage</option>
                        <option value="drainage">Drainage Problem</option>
                        <option value="noise">Noise Complaint</option>
                        <option value="safety">Safety Hazard</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="5" placeholder="Describe the issue in detail..." required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Location/Address</label>
                    <input type="text" name="location" class="form-control" placeholder="Street, Subdivision, Landmark" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Upload Photo (Optional)</label>
                    <input type="file" name="photo" class="form-control file-upload-input" accept="image/*">
                    <div class="file-preview" style="display:none;"></div>
                </div>
                <div class="form-group">
                    <label class="form-label">Contact Information</label>
                    <input type="tel" name="contact" class="form-control" placeholder="Your contact number">
                </div>
                <button type="submit" class="btn btn-primary btn-large">Submit Report</button>
            </form>
        </div>
    </section>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/form-validation.js"></script>
</body>
</html>''',
}

# Write HTML files
for filename, content in html_files.items():
    with open(os.path.join(base_path, filename), 'w') as f:
        f.write(content)

print(f"✓ Created {len(html_files)} HTML files")

# Generate JavaScript files
js_files = {
    'form-validation.js': '''// Form Validation
$(document).ready(function() {
    // Email validation
    function validateEmail(email) {
        return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email);
    }
    
    // Phone validation
    function validatePhone(phone) {
        return /^[\\+]?[(]?[0-9]{3}[)]?[-\\s\\.]?[0-9]{3}[-\\s\\.]?[0-9]{4,6}$/.test(phone);
    }
    
    // Login form
    $('#loginForm').submit(function(e) {
        e.preventDefault();
        const email = $('input[name="email"]').val();
        const password = $('input[name="password"]').val();
        
        if (!validateEmail(email)) {
            alert('Please enter a valid email address');
            return false;
        }
        
        if (password.length < 6) {
            alert('Password must be at least 6 characters');
            return false;
        }
        
        this.submit();
    });
    
    // Register form
    $('#registerForm').submit(function(e) {
        const password = $('#password').val();
        const confirmPassword = $('input[name="confirm_password"]').val();
        
        if (password !== confirmPassword) {
            e.preventDefault();
            alert('Passwords do not match');
            return false;
        }
        
        if (password.length < 8) {
            e.preventDefault();
            alert('Password must be at least 8 characters');
            return false;
        }
    });
    
    // Report form
    $('#reportForm').submit(function(e) {
        const category = $('select[name="category"]').val();
        const description = $('textarea[name="description"]').val();
        
        if (!category) {
            e.preventDefault();
            alert('Please select an issue category');
            return false;
        }
        
        if (description.length < 20) {
            e.preventDefault();
            alert('Please provide a more detailed description (at least 20 characters)');
            return false;
        }
    });
});''',

    'map-integration.js': '''// Google Maps Integration
function initMap() {
    // Barangay Sto. Rosario Hall coordinates
    const barangayLocation = { lat: 15.1451, lng: 120.5880 };
    
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: barangayLocation,
    });
    
    const marker = new google.maps.Marker({
        position: barangayLocation,
        map: map,
        title: 'Barangay Sto. Rosario Hall'
    });
    
    const infoWindow = new google.maps.InfoWindow({
        content: '<h3>Barangay Sto. Rosario Hall</h3><p>Angeles City, Pampanga</p>'
    });
    
    marker.addListener('click', function() {
        infoWindow.open(map, marker);
    });
}''',

    'filter-search.js': '''// Announcement Filtering and Search
$(document).ready(function() {
    // Category filter
    $('.category-filter').click(function() {
        const category = $(this).data('category');
        
        if (category === 'all') {
            $('.announcement-card').show();
        } else {
            $('.announcement-card').hide();
            $(`.announcement-card[data-category="${category}"]`).show();
        }
        
        $('.category-filter').removeClass('active');
        $(this).addClass('active');
    });
    
    // Search functionality
    $('#announcementSearch').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        
        $('.announcement-card').each(function() {
            const title = $(this).find('h3').text().toLowerCase();
            const content = $(this).find('p').text().toLowerCase();
            
            if (title.includes(searchTerm) || content.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
});''',

    'report-tracker.js': '''// Report Status Tracking
$(document).ready(function() {
    function loadReportStatus(reportId) {
        $.ajax({
            url: 'php/get-report-status.php',
            method: 'GET',
            data: { report_id: reportId },
            success: function(response) {
                const data = JSON.parse(response);
                updateStatusDisplay(data);
            }
        });
    }
    
    function updateStatusDisplay(report) {
        const statusColors = {
            'pending': '#ffc107',
            'in_progress': '#ca52cc',
            'resolved': '#28a745',
            'closed': '#666666'
        };
        
        $('#reportStatus').html(`
            <div class="status-badge" style="background: ${statusColors[report.status]}">
                ${report.status.replace('_', ' ').toUpperCase()}
            </div>
            <p>${report.status_message}</p>
            <p class="status-date">Last updated: ${report.updated_at}</p>
        `);
    }
});''',
}

for filename, content in js_files.items():
    with open(os.path.join(base_path, 'js', filename), 'w') as f:
        f.write(content)

print(f"✓ Created {len(js_files)} JavaScript files")

print("\\n✅ Project files generated successfully!")
print(f"📁 Location: {base_path}")
print("\\n📝 Next steps:")
print("1. Add remaining HTML pages (about, updates, emergency, tourism, transparency, contact)")
print("2. Create PHP backend files")
print("3. Set up database with database-schema.sql")
print("4. Upload images to /images/ directory")
print("5. Configure database connection in php/db-connection.php")
print("6. Test on local server")
